package com.tidal.refactoring.playlist.exception;

public class PlaylistException extends RuntimeException {

	private static final long serialVersionUID = 759495431208011733L;

	public PlaylistException(String s) {
        super(s);
    }
}
