package com.tidal.refactoring.playlist;

import com.google.inject.Inject;
import com.tidal.refactoring.playlist.dao.PlaylistDaoBean;
import com.tidal.refactoring.playlist.data.PlayListTrack;
import com.tidal.refactoring.playlist.data.Track;
import com.tidal.refactoring.playlist.exception.PlaylistException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Guice;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.testng.AssertJUnit.*;

@Guice(modules = TestBusinessModule.class)
public class PlaylistBusinessBeanTest {

    @Inject
    PlaylistBusinessBean playlistBusinessBean;


    List<Track> trackList;
    List<Integer> indexesToDelete;

    @BeforeMethod
    public void setUp() throws Exception {
        trackList = new ArrayList<>();
        Track track = new Track();
        track.setArtistId(4);
        track.setTitle("A brand new track");
        track.setId(76868);
        trackList.add(track);

        indexesToDelete = new ArrayList<>();
        indexesToDelete.add(0);
        indexesToDelete.add(10);
        indexesToDelete.add(15);
    }

    @AfterMethod
    public void tearDown() throws Exception {

    }

    @Test
    public void testAddTracks_shouldReturnAddedTracks() throws Exception {
        List<PlayListTrack> playListTracks = playlistBusinessBean.addTracks(
                UUID.randomUUID().toString(), trackList, 5);
        assertNotNull(playListTracks.get(0));
    }

    @Test
    public void testAdd5Tracks_shouldReturn5AddedTracks() throws Exception {

        List<Track> trackList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Track track = new Track();
            track.setArtistId(i);
            track.setTitle("A  new kind of track");
            track.setId(i);
            trackList.add(track);
        }
        List<PlayListTrack> playListTracks = playlistBusinessBean.addTracks(
                UUID.randomUUID().toString(), trackList, 5);
        assertEquals(5, playListTracks.size());
    }


    @Test(expectedExceptions = {PlaylistException.class})
    public void testAddTracksMoreThan500_shouldThrowPlayListException() throws PlaylistException {
        List<Track> trackList = new ArrayList<>();
        for (int i = 0; i < 501; i++) {
            Track track = new Track();
            track.setArtistId(i);
            track.setTitle("A brand new track");
            track.setId(i);
            trackList.add(track);
        }
        playlistBusinessBean.addTracks(UUID.randomUUID().toString(), trackList, 5);

    }



    @Test
    public void testRemoveTrack_shouldHaveCorrectIndex() {
        List<PlayListTrack> playListTracks =
                playlistBusinessBean.removeTracks(UUID.randomUUID().toString(), indexesToDelete);
        assertEquals(3, playListTracks.get(3).getIndex());
    }

    @Test(expectedExceptions = {PlaylistException.class})
    public void testRemoveTrackWithInvalidIndices_shouldThrowPlayListException() {
        indexesToDelete.add(-13);
        playlistBusinessBean.removeTracks(UUID.randomUUID().toString(), indexesToDelete);
    }
}